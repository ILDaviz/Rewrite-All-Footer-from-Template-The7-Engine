-- EN --

# This plug-in modifies all footers automatically post or page if you use the The7 template engine

If you use the7 engine as a template engine, it often happens that the save system disables the footer of the page or sets it differently. To prevent this change from happening, this plug-in will change all footers of pages or posts in an easy and practical way. Create a zip of this repo and install from the Plugins page.


-- IT --

# Questo plug-in modifica tutti i footer in modo automatico post o pagina se si usa il template engine The7

Se si usa il motore the7 come template engine, vi capità spesso che il sistema di salvattaggio diasibiliti il footer della pagina o lo imposti differente. Per evitare che succeda questo cambio, questo plug-in modificherà in un colpo solo tutti i footer di pagine o post in modo facile e pratico. Crea uno zip di questa repo e installa dalla pagina Plugins.